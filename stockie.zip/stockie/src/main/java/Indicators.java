public class Indicators {
/*
* Klasse welche statische Methoden zur Berechnung von Indikatoren haelt.
* */
    public Indicators(){
        //implement singleton here
    }

}
